<?php
include 'temp/db.php';
include 'temp/head.php';
include 'temp/nav_user.php';
session_start();
$id_user = $_SESSION['id_user'];

if (!empty($_GET)) {
    $id_application = $_GET['id_application'];
    $sql = "DELETE FROM applications WHERE id_application = '$id_application'";
    $result = $mysqli->query($sql);
}

if (!empty($_POST)) {
    $status = $_POST['status'];
    $sql = "SELECT * FROM applications WHERE status LIKE '%$status%'";
    $result = $mysqli->query($sql);
}
?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <h1 style="text-align:center">Личный кабинет</h1>
            <form class="row row-cols-lg-auto g-3 align-items-center" action="" method="POST">
                <div class="col-12">
                    <div class="input-group">
                        <input type="text" class="form-control" name="status" id="status" placeholder="Статус">
                    </div>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-warning">Найти</button>
                </div>
            </form>
        </div>
    </div>
    <div class="row">
        <table border="1" class="table">
            <tr class="table-warning">
                <th>Название заявки</th>
                <th>Описание заявки</th>
                <th>Категория заявки</th>
                <th>Дата заявки</th>
                <th>Статус</th>
                <th></th>
            </tr>
            <?php
            $sql = "SELECT * FROM applications, categories WHERE applications.id_category = categories.id_category AND id_user = $id_user ORDER BY date_application DESC";
            $result = $mysqli->query($sql);
            foreach ($result as $row) {
                echo '<tr><td>' . $row['name_application'] . '</td>
                    <td>' . $row['description'] . '</td>
                    <td>' . $row['name_category'] . '</td>
                    <td>' . $row['date_application'] . '</td>
                    <td>' . $row['status'] . '</td>';
                if ($row['status'] =='Новая') {
                    echo '<td><a class="btn btn-warning" href="personal_account.php?id_application='.$row['id_application'].'" role="button">Удалить</a></td></tr>';
                } else {
                    echo '<td></td></tr>';
                }
            }
            ?>
        </table>
    </div>
</div>