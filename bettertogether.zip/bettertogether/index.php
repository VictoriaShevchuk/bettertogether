<?php
include 'temp/db.php';
include 'temp/head.php';
session_start();
if (isset($_SESSION['id_user'])) {
    if ($_SESSION['id_user'] == 1) {
        include 'temp/nav_admin.php';
    } else {
        include 'temp/nav_user.php';
    }
} else {
    include 'temp/nav.php';
}


?>
<div class="container">
    <div class="row">
        <div class="col-lg-1"></div>
        <div class="col-lg-10">
            <?php
            $sql = "SELECT COUNT(*) AS count FROM applications WHERE status='Решена'";
            $result = $mysqli->query($sql);
            foreach ($result as $row) {
                echo '<div style="text-align: center; font-size: 26px"><b>Количество решенных заявок: '.$row['count'].'</b></div>';
            }
            ?>
        </div>
        <div class="col-lg-1"></div>
    </div>
    <div class="row">
        <div class="col-lg-12">
        <?php
            $sql = "SELECT name_application, photo_do, photo_posle, date_application, status, name_category FROM applications, categories WHERE applications.id_category = categories.id_category AND status='Решена' ORDER BY date_application DESC LIMIT 4";
            $resul1 = $mysqli->query($sql);
            echo '<div class="row row-cols-1 row-cols-md-4 g-8">';
            foreach ($resul1 as $row) { 
                echo '<div class="card" style="width: 18rem;">
                <img src="'.$row['photo_do'].'" class="card-img-top" alt="...">
                <div class="card-body">
                <h5 class="card-title">'.$row['name_application'].'</h5>
                <p class="card-text">'.$row['name_category'].'</p>
                <div class="card-footer">'.$row['date_application'].'</div>
                </div>
                </div>';
            }
            echo '</div>'
            ?>
        </div>
    </div>
</div>
<?php
include 'temp/footer.php';
?>