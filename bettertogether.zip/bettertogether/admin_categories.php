<?php
include 'temp/db.php';
include 'temp/head.php';
include 'temp/nav_admin.php';
if (!empty($_GET)) {
    $id_category = $_GET['id_category'];
    $sql = "DELETE FROM categories WHERE id_category = '$id_category'";
    $result = $mysqli->query($sql);
}
if (!empty(($_POST))) {
    $name_category = $_POST['name_category'];
    $sql = "INSERT INTO categories (name_category) VALUES ('$name_category')";
    $result = $mysqli->query($sql);
}

?>
<div class="container">
    <div class="row">
        <div class="col-4"></div>
        <div class="col-4">
            <h1 style="text-align:center">Категории заявок</h1>
            <form class="row row-cols-lg-auto g-3 align-items-center" action="" method="POST">
                <div class="col-12">
                    <div class="input-group">
                        <input type="text" class="form-control" name="name_category" id="name_category"
                            placeholder="Название категории">
                    </div>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-warning">Добавить</button>
                </div>
            </form>
        </div>
        <div class="col-4"></div>
    </div>
</div>
<div class="row">
    <div class="col-4"></div>
    <div class="col-4">
        <table border="1" class="table">
            <tr class="table-warning">
                <th>Название заявки</th>
                <th></th>
            </tr>
            <?php
            $sql = "SELECT * FROM categories";
            $result = $mysqli->query($sql);
            foreach ($result as $row) {
                echo '<tr><td>' . $row['name_category'] . '</td>
                    <td><a class="btn btn-warning" href="admin_categories.php?id_category=' . $row['id_category'] . '" role="button">Удалить</a></td></tr>';
            }
            ?>
        </table>
    </div>
    <div class="col-4"></div>
</div>
</div>