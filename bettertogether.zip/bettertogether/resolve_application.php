<?php
include 'temp/db.php';
include 'temp/head.php';
include 'temp/nav_admin.php';

if (!empty($_POST['userfile'])) {
    $id_application = $_GET['id_application'];
    $dir = 'img/reject/';
    $file = $dir. basename($_FILES['userfile']['name']);
    $photo_posle = '/reject/'. basename($_FILES['userfile']['name']);
    if (move_uploaded_file($_FILES['userfile']['tmp_name'], $file)) 
    {
        $sql = "UPDATE applications SET status='Решена', photo_posle='$photo_posle' WHERE id_application = $id_application";
        var_dump($sql);
        $result = $mysqli->query($sql);
        if ($result) {
            header('location: admin_application.php');
        }
        else {
            echo "Ошибка";
          }
    } 
    else {
      echo "Возможная атака с помощью файловой загрузки!\n";
    }
}
?>
<div class="container">
    <div class="row">
        <div class="col-lg-3"></div>
        <div class="col-lg-6">
            <h1 style="text-align: center">Решить проблему</h1>
            <hr>
            <form enctype="multipart/form-data" action="" method="POST">
                <div class="mb-3">
                    Фото после
                    <input name="userfile" type="file" class="form-control" required>
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-warning">Отправить</button>
                </div>
            </form>
        </div>
        <div class="col-lg-3"></div>
    </div>
</div>