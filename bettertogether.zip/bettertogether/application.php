<?php
include 'temp/db.php';
include 'temp/head.php';
include 'temp/nav_user.php';
session_start();
$id_user = $_SESSION['id_user'];
if (!empty(($_POST))) {
    $name_application = $_POST['name_application'];
    $description = $_POST['description'];
    $id_category = $_POST['id_category'];
    $date = date("y-m-d");
    $dir = 'img/';
    $file = $dir. basename($_FILES['userfile']['name']);
    move_uploaded_file($_FILES['userfile']['tmp_name'], $file);
    $sql = "INSERT INTO applications  (id_user, name_application, description, id_category, photo_do, date_application) VALUES ($id_user, '$name_application', '$description', '$id_category', '$file', '$date')";
    $result = $mysqli->query($sql);
    if ($result) {
    header('location: personal_account.php');
    } 
}
?>
<div class="container">
    <div class="row">
        <div class="col-lg-3"></div>
        <div class="col-lg-6">
            <h1 style="text-align: center">Оставить заявку</h1>
            <hr>
            <form enctype="multipart/form-data" class="form-inline" action="" method="POST">
                <div class="mb-3">
                    <label for="name_application" class="form-label">Название</label>
                    <input type="text" class="form-control" name="name_application" id="name_application" required>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Описание</label>
                    <input type="text" class="form-control" name="description" id="description" required><br>
                </div>
                <div class="mb-3">
                    <label class="form-label">Категория</label>
                    <select class="form-select" name="id_category">
                        <?php
                        $category = $mysqli->query("SELECT id_category, name_category FROM categories");
                        foreach ($category as $list) {
                            echo '<option value="'.$list["id_category"].'">'.$list["name_category"].'</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="mb-3">
                    Фото
                    <input name="userfile" type="file" class="form-control" required>
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-warning">Оставить</button>
                </div>
            </form>
        </div>
        <div class="col-lg-3"></div>
    </div>
</div>