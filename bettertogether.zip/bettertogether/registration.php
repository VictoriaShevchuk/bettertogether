<?php
include 'temp/db.php';
include 'temp/head.php';
include 'temp/nav.php';
$message = "";
if (!empty(($_POST))) {
    $fio = $_POST['fio'];
    $email = $_POST['email'];
    $login = $_POST['login'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    if ($password == $password2) {
        $sql = "INSERT INTO users (fio, email, login, password) VALUES ('$fio', '$email', '$login', '$password')";
        $result = $mysqli->query($sql);
        if ($result) {
            header('location: authorization.php');
        } else {
            $message = 'Ошибка';
        }
    } else {
        $message = 'Неверно подтвержденный пароль';
    }
}
?>
<div class="container">
    <div class="row">
        <div class="col-lg-3"></div>
        <div class="col-lg-6">
            <h1 style="text-align: center">Регистрация</h1>
            <hr>
            <form class="form-inline" action="" method="POST">
                <div class="mb-3">
                    <label for="fio" class="form-label">ФИО</label>
                    <input type="text" class="form-control" name="fio" id="fio" pattern="/^[а-яёА-ЯЁ\s-]+$/u" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">E-mail</label>
                    <input type="email" class="form-control" name="email" id="email" required>
                </div>
                <div class="mb-3">
                    <label for="login" class="form-label">Логин</label>
                    <input type="text" class="form-control" name="login" id="login" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Пароль</label>
                    <input type="password" class="form-control" name="password" id="password" required>
                </div>
                <div class="mb-3">
                    <label for="password2" class="form-label">Повторите пароль</label>
                    <input type="password" class="form-control" name="password2" id="password2" required>
                </div>
                <div class="mb-3">
                    <label>
                        <input type="checkbox" name="consent" required>
                        Согласие на обработку персональных данных 
                    </label>
                </div>
                <?php if(!empty($message)) {
echo '<div class="alert alert-danger" role="alert">'.$message.'</div>';
                }
                ?>
                <div class="mb-3">
                    <button type="submit" class="btn btn-warning">Зарегистрироваться</button>
                </div>
            </form>
        </div>
        <div class="col-lg-3"></div>
    </div>
</div>