<?php
include 'temp/db.php';
include 'temp/head.php';
include 'temp/nav_admin.php';

if (!empty($_POST)) {
    $id_application = $_GET['id_application'];
    $comment = $_POST['comment'];
    $sql = "UPDATE applications SET status='Отклонена', comment = '$comment' WHERE id_application = $id_application";
    $result = $mysqli->query($sql);
    if ($result) {
        header('location: admin_application.php');
    }
}
?>
<div class="container">
    <div class="row">
        <div class="col-lg-3"></div>
        <div class="col-lg-6">
            <h1 style="text-align: center">Отклонить заявку</h1>
            <hr>
            <form enctype="multipart/form-data" class="form-inline" action="" method="POST">
                <div class="mb-3">
                    <label for="floatingTextarea">Причина отказа</label>
                    <textarea class="form-control" id="floatingTextarea" name="comment"></textarea>
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-warning">Отправить</button>
                </div>
            </form>
        </div>
        <div class="col-lg-3"></div>
    </div>
</div>