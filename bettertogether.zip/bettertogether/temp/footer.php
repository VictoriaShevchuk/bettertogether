<footer style="margin-top: 20px; padding-top:20px; padding-bottom:20px; background-color: #ffc107;">
        <div class="container bg-prime text-white">
         <div class="row">
             <div class="col-1"></div>
             <div class="col-4">                    
                <div class ="copy">
                <p style="text-align: center">
                Copyright <?php echo '&copy2025'; ?>
                </p>
            </div></div>  
             <div class="col-4">
             </div>
             <div class="col-2"></div>    
             <div class="col-1"></div>
         </div>
     </div>
    </footer>
    </body>
</html>