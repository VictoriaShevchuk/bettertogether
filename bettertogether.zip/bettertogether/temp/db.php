<?php 
$mysqli = new mysqli('localhost', 'root', '', 'bettertogether');
$mysqli->set_charset('utf-8');
?>