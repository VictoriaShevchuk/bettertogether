<?php
include 'temp/db.php';
include 'temp/head.php';
include 'temp/nav_admin.php';

if (!empty($_GET)) {
    $id_application = $_GET['id_application'];
    if (!empty($_GET['action'] == 'resolve')) {
        $sql = "UPDATE applications SET status='Решена' WHERE id_application = $id_application";
        $result = $mysqli->query($sql);
    } elseif (!empty($_GET['action'] == 'reject')) {
        $sql = "UPDATE applications SET status='Отклонена' WHERE id_application = $id_application";
        $result = $mysqli->query($sql);
    }

}

?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <h1 style="text-align:center">Заявки</h1>
        </div>
    </div>
    <div class="row">
        <table border="1" class="table">
            <tr class="table-warning">
                <th>Название заявки</th>
                <th>Пользователь</th>
                <th>Описание заявки</th>
                <th>Категория заявки</th>
                <th>Дата заявки</th>
                <th>Статус</th>
                <th></th>
            </tr>
            <?php
            $sql = "SELECT * FROM applications, categories, users WHERE applications.id_category = categories.id_category AND users.id_user = applications.id_user ORDER BY date_application DESC";
            $result = $mysqli->query($sql);
            foreach ($result as $row) {
                echo '<tr><td>' . $row['name_application'] . '</td>
                <td>' . $row['fio'] . '</td>
                    <td>' . $row['description'] . '</td>
                    <td>' . $row['name_category'] . '</td>
                    <td>' . $row['date_application'] . '</td>
                    <td>' . $row['status'] . '</td>';
                if ($row['status'] == 'Новая') {
                    echo '<td><a class="btn btn-warning" href="resolve_application.php?id_application=' . $row['id_application'] . '" role="button">Решить</a>
                    <a class="btn btn-warning" href="reject_application.php?id_application=' . $row['id_application'] . '" role="button">Отклонить</a></td></tr>';
                } else {
                    echo '<td></td></tr>';
                }
            }
            ?>
        </table>
    </div>
</div>